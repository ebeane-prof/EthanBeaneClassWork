#!/bin/bash
# Arg1 $1 should be the language of the assignment.
language=$1

if [ ! "$(uname)" = Linux ]; then
    echo "Run this on a Linux platform!"
    exit 1
fi

if ! command -v delta &>/dev/null; then
    git clone https://github.com/dandavison/delta.git
    cd delta
    make
    cd ../
    export PATH=$PATH:$(pwd)/delta/target/release/
fi

for package_name in make file sha512sum python3; do
    if ! command -v $package_name &>/dev/null; then
        echo Install $package_name before proceeding.
        exit 1
    fi
done

for python_package_name in Levenshtein; do
    if ! python3 -c "import $python_package_name"; then
        echo Install $python_package_name before proceeding.
        exit 1
    fi
done

if [ $language = "python" ] || [ $language = "anylang" ]; then
    # Some OS's (OpenSuse) install pudb3 as pudb
    if command -v pudb3 >/dev/null 2>&1; then
        pudb3=pudb3
    else
        pudb3=pudb
    fi
    if ! command -v $pudb3 &>/dev/null; then
        echo "Install pudb3 before proceeding."
        exit 1
    fi
    for package_name in mypy black py2cfg pyflakes; do
        if ! command -v $package_name &>/dev/null; then
            echo Install $package_name before proceeding.
            exit 1
        fi
    done
fi

if [ $language = "haskell" ] || [ $language = "anylang" ]; then
    # Some OS's (OpenSuse) install pudb3 as pudb
    for package_name in ghc cabal ormolu stack doctest stan; do
        if ! command -v $package_name &>/dev/null; then
            echo Install $package_name before proceeding.
            exit 1
        fi
    done
fi

if [ $language = "bash" ] || [ $language = "anylang" ]; then
    for package_name in shellcheck shfmt; do
        if ! command -v $package_name &>/dev/null; then
            echo Install $package_name before proceeding.
            exit 1
        fi
    done
fi

if [ $language = "cpp" ] || [ $language = "anylang" ]; then
    for package_name in clang-format make cppcheck gdb valgrind valgreen; do
        if ! command -v $package_name &>/dev/null; then
            echo Install $package_name before proceeding.
            exit 1
        fi
    done
fi

if [ $language = "rust" ] || [ $language = "anylang" ]; then
    for package_name in rustc gdb rustfmt; do
        if ! command -v $package_name &>/dev/null; then
            echo Install $package_name before proceeding.
            exit 1
        fi
    done
fi
