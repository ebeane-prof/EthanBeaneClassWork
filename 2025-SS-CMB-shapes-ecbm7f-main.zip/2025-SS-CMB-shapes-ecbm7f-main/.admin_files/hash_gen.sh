#!/bin/bash
BASEDIR=$(dirname "$0")
cd "$BASEDIR" || exit 1

# this is because '_' sorts differently with different locales
LC_COLLATE=C

# To produce null strings when no match
shopt -s nullglob
# To enable !(nothis)
shopt -s extglob

# To init the file (anew)
sha512sum ../.gitlab-ci.yml >hashes.txt

arr=(
    !(*hashes.txt)
    ../Cargo.toml
    ../*.cabal
    ../Makefile
    ../Makefile_grade
    ../src/Makefile
    ../tests/*/Makefile
    ../tests/*/*.goal
    ../tests/*/*.in
    ../tests/*/*.py
    ../tests/*/*.rs
    ../tests/*/*.cpp
    ../tests/*/*.h
    ../tests/*/*.hpp
    ../tests/*/*.c
    ../tests/*/*.sh
    ../tests/*/*.m
    ../tests/*/*.hs
    ../tests/*/goal.ast
    ../tests/*/goal.svg
)

for file_to_hash in "${arr[@]}"; do
    if [ -f "$file_to_hash" ]; then
        sha512sum "$file_to_hash" >>hashes.txt
    fi
done

shopt -u nullglob
shopt -u extglob
