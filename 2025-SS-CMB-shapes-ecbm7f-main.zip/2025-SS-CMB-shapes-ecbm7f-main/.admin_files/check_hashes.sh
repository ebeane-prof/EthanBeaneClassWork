#!/bin/bash
BASEDIR=$(dirname "$0")
cd "$BASEDIR" || exit 1

# This should be run before any file students could potentially edit.
# Assumes you've added the relevant files to hash_gen.sh
# usage: check_hashes
bash hash_gen.sh
if diff hashes.txt grader_hashes.txt &>/dev/null; then
    :
    # echo "Hashes ok"
else
    echo -e "\nDon't edit any of the autograder's files, or you will fail!"
    echo "Notice the files listed below, with the long hashes in front of them."
    echo -e "Those are the files you broke.\n"
    delta hashes.txt grader_hashes.txt
    echo -e "\nIf you are seeing this, then type:"
    echo "    $ git log --all --graph --show-signature"
    echo "Then look at the log to find the first four letters of the hash of the instructor's last commit; copy it."
    echo "Then type:"
    echo "    $ git checkout firstfourlettersofthehashoftheinstructorslastcommit fileorfolderyoubroke"
    echo -e "You must do this for each file you broke (or just the super-folder of the grader-files), and then re-run grade.sh.\n"
    grade=0
    echo "You edited our stuff, so you get a 0; see the output for details."
    cd ..
    make clean
    [[ "$IS_PIPELINE" ]] && echo 0 >grade || rm -f grade
    exit 1
fi
